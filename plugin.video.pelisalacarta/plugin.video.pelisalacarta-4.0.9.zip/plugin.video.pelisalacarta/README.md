# pelisalacarta

## Classic python version

If you want to develop with pelisalacarta you can start doing it on this "main-classic" folder.

It contains the current development version, configured to work on the latest Kodi. What i do is to link this to my Kodi "addons" folder so i can modify code and test it on-the-fly.

If you are using Mac OS X you can do this with these commands.

cd 
cd Library/Application\ Support/Kodi/addons/
ln -s /Users/jesus/pelisalacarta/python/main-classic plugin.video.pelisalacarta

If you are using Linux commands are

cd 
cd .kodi/addons
ln -s /home/jesus/pelisalacarta/python/main-classic plugin.video.pelisalacarta

On Windows i leave it as exercise :)

After that you will see that pelisalacarta is installed and ready in Kodi